# IDS GUI with Packet Filtering + GeoIP Lookup + Countdown Timer + IP Location + Pie Chart + Malicious IP View + PDF Report
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
from scapy.all import sniff, IP, TCP, UDP, ICMP
from joblib import load
import pandas as pd
import threading
import requests
import time
import matplotlib.pyplot as plt
from collections import defaultdict
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from datetime import datetime

# Load model
model = load("C:/Users/Manoj Kumar/Downloads/ids_model.pkl")

packet_log = []
safe_count = 0
malicious_count = 0
total_packets = 0
malicious_ip_counter = defaultdict(int)

# GUI setup
root = tk.Tk()
root.title("Intrusion Detection System")
root.geometry("700x500")
root.resizable(False, False)

# Top status
status_label = tk.Label(root, text="", font=("Arial", 12))
status_label.pack(pady=5)

# Countdown label
countdown_label = tk.Label(root, text="", font=("Arial", 12, "bold"), fg="blue")
countdown_label.pack(pady=2)

# Filters
filter_frame = tk.Frame(root)
filter_frame.pack(pady=5)

search_var = tk.StringVar()
search_entry = tk.Entry(filter_frame, textvariable=search_var, width=30)
search_entry.grid(row=0, column=0, padx=5)

proto_var = tk.StringVar(value="All")
proto_dropdown = ttk.Combobox(filter_frame, textvariable=proto_var, values=["All", "TCP", "UDP", "ICMP"])
proto_dropdown.grid(row=0, column=1, padx=5)

status_var = tk.StringVar(value="All")
status_dropdown = ttk.Combobox(filter_frame, textvariable=status_var, values=["All", "Safe", "Malicious"])
status_dropdown.grid(row=0, column=2, padx=5)

def apply_filters():
    result_text.config(state='normal')
    result_text.delete('1.0', tk.END)
    for number, status, summary, src_ip, dst_ip, src_loc, dst_loc in packet_log:
        if search_var.get() not in src_ip and search_var.get() not in dst_ip:
            continue
        if status_var.get() != "All" and status_var.get() not in status:
            continue
        if proto_var.get() != "All" and proto_var.get() not in summary:
            continue
        tag = "malicious" if "Malicious" in status else None
        line = (f"Packet #{number}: {status} - {summary}\n"
                f"From: {src_ip} ({src_loc}) -> To: {dst_ip} ({dst_loc})\n")
        result_text.insert(tk.END, line, tag)
    result_text.tag_config("malicious", foreground="red")
    result_text.config(state='disabled')

search_btn = tk.Button(filter_frame, text="Apply Filters", command=apply_filters)
search_btn.grid(row=0, column=3, padx=5)

# Result text
result_text = scrolledtext.ScrolledText(root, width=85, height=15, state='disabled', font=("Consolas", 10))
result_text.pack(pady=10)

# Get location info
def get_ip_location(ip):
    try:
        r = requests.get(f"https://ipinfo.io/{ip}/json", timeout=3)
        data = r.json()
        return f"{data.get('city', 'Unknown')}, {data.get('country', 'Unknown')}"
    except:
        return "Unknown"

# Extract features
def extract_features(pkt):
    if IP in pkt:
        ip_layer = pkt[IP]
        proto = ip_layer.proto
        pkt_len = len(pkt)
        src_port = dst_port = -1
        flags = 0
        src_ip = ip_layer.src
        dst_ip = ip_layer.dst

        if TCP in pkt:
            src_port = pkt[TCP].sport
            dst_port = pkt[TCP].dport
            flags = pkt[TCP].flags
        elif UDP in pkt:
            src_port = pkt[UDP].sport
            dst_port = pkt[UDP].dport
        elif ICMP in pkt:
            proto = 1

        df = pd.DataFrame([{
            'proto': proto, 'pkt_len': pkt_len,
            'src_port': src_port, 'dst_port': dst_port,
            'flags': flags
        }])
        return df, pkt.summary(), src_ip, dst_ip
    return None, None, None, None

# Detection
def detect(pkt):
    global safe_count, malicious_count, total_packets
    features, summary, src_ip, dst_ip = extract_features(pkt)
    if features is not None:
        features = features.fillna(-1)
        try:
            pred = model.predict(features)
            total_packets += 1
            status = '✅ Safe' if pred[0] == 0 else '❌ Malicious'
            if pred[0] == 0:
                safe_count += 1
            else:
                malicious_count += 1
                malicious_ip_counter[src_ip] += 1
            src_loc = get_ip_location(src_ip)
            dst_loc = get_ip_location(dst_ip)
            packet_log.append((total_packets, status, summary, src_ip, dst_ip, src_loc, dst_loc))
        except Exception as e:
            packet_log.append((total_packets, '⚠ Error', str(e), src_ip, dst_ip, "Unknown", "Unknown"))

# Countdown updater
def update_countdown(seconds):
    for remaining in range(seconds, 0, -1):
        countdown_label.config(text=f"⏳ Time Remaining: {remaining} sec")
        time.sleep(1)
    countdown_label.config(text="")

# Pie chart visualizer
def show_pie_chart():
    labels = ['Safe', 'Malicious']
    sizes = [safe_count, malicious_count]
    colors = ['#4CAF50', '#F44336']
    plt.figure(figsize=(4, 4))
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
    plt.axis('equal')
    plt.title('Packet Scan Results')
    plt.show()

# Show malicious IPs
def show_malicious_ips():
    top = tk.Toplevel(root)
    top.title("Malicious IPs")
    text = tk.Text(top, width=50, height=15)
    text.pack(padx=10, pady=10)
    for ip, count in malicious_ip_counter.items():
        text.insert(tk.END, f"{ip} - seen {count} times\n")
    text.config(state='disabled')

# Generate PDF Report
def generate_report():
    filename = f"IDS_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    c = canvas.Canvas(filename, pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(100, 750, f"Intrusion Detection System Report")
    c.drawString(100, 730, f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    c.drawString(100, 710, f"Total Packets: {total_packets}")
    c.drawString(100, 690, f"Safe Packets: {safe_count}")
    c.drawString(100, 670, f"Malicious Packets: {malicious_count}")
    c.drawString(100, 640, "Malicious IPs:")
    y = 620
    for ip, count in malicious_ip_counter.items():
        c.drawString(120, y, f"{ip} - seen {count} times")
        y -= 20
        if y < 100:
            c.showPage()
            y = 750
    c.save()
    messagebox.showinfo("Report", f"Report saved as {filename}")

# Run scan
def run_scan():
    status_label.config(text="Scanning packets for 30 seconds...")
    countdown_thread = threading.Thread(target=update_countdown, args=(30,))
    countdown_thread.start()
    sniff(timeout=30, prn=detect, store=0)
    status_label.config(text=f"✅ Scan Complete! Total: {total_packets} | Safe: {safe_count} | Malicious: {malicious_count}")
    apply_filters()
    show_pie_chart()

# Start detection
def start_detection():
    global total_packets, safe_count, malicious_count, packet_log, malicious_ip_counter
    total_packets = safe_count = malicious_count = 0
    packet_log.clear()
    malicious_ip_counter.clear()
    result_text.config(state='normal')
    result_text.delete('1.0', tk.END)
    result_text.config(state='disabled')
    threading.Thread(target=run_scan).start()

# Buttons
start_btn = tk.Button(root, text="Start Scan", font=("Arial", 12), command=start_detection)
start_btn.pack(pady=5)

malicious_btn = tk.Button(root, text="⚠️ View Malicious IPs", font=("Arial", 10), command=show_malicious_ips)
malicious_btn.pack(pady=2)

report_btn = tk.Button(root, text="📝 Generate Report", font=("Arial", 10), command=generate_report)
report_btn.pack(pady=2)

exit_btn = tk.Button(root, text="Exit", font=("Arial", 12), command=root.destroy)
exit_btn.pack(pady=5)

root.mainloop()
